package com.security.runner;

import com.security.entity.Employee;
import com.security.repository.EmployeeRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * This class is responsible to add one admin user in Employee database, since
 * createEmployee api is authorize with role ADMIN
 */
@Component
public class AdminBootstrap implements CommandLineRunner {

    private final EmployeeRepository repository;
    private final PasswordEncoder passwordEncoder;

    public AdminBootstrap(EmployeeRepository repository,
                          PasswordEncoder passwordEncoder) {
        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {

        if (repository.existsByUsername("admin")) {
            return;
        }

        Employee admin = new Employee();
        admin.setUsername("admin");
        admin.setPassword(passwordEncoder.encode("admin123"));
        admin.setRole("ROLE_ADMIN");
        repository.save(admin);
    }
}

