package com.security.controller;

import com.security.model.LoginRequest;
import com.security.model.LoginResponse;
import com.security.util.JwtUtil;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class LoginController {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;

    @PostMapping("/api/login")
    public ResponseEntity<LoginResponse> login(@Valid @RequestBody LoginRequest request) {

        UsernamePasswordAuthenticationToken unauthenticatedAuthObj = UsernamePasswordAuthenticationToken.unauthenticated(request.getUsername(), request.getPassword());

        //UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(request.getUsername(), request.getPassword());
        Authentication authentication = authenticationManager.authenticate(unauthenticatedAuthObj);

        UserDetails user = (UserDetails) authentication.getPrincipal();
        String token = jwtUtil.generateToken(user);
        HttpHeaders headers = new HttpHeaders();
        headers.add(HttpHeaders.AUTHORIZATION, "Bearer " + token);

        LoginResponse response = new LoginResponse(user.getUsername(),
                user.getAuthorities().stream()
                        .map(a -> a.getAuthority())
                        .toList(),
                "Bearer",
                jwtUtil.getExpirationTime().toMinutes(), token
        );
        return ResponseEntity.ok().headers(headers).body(response);
    }
}
