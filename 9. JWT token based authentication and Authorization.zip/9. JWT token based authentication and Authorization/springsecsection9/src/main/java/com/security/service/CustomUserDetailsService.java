package com.security.service;

import com.security.entity.Employee;
import com.security.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

        private final EmployeeRepository employeeRepository;

//        public CustomUserDetailsService(EmployeeRepository employeeRepository) {
//            this.employeeRepository = employeeRepository;
//        }

        @Override
        public UserDetails loadUserByUsername(String username)
                throws UsernameNotFoundException {
            Employee emp = employeeRepository.findByUsername(username).orElseThrow(() ->
                            new UsernameNotFoundException("User not found: " + username));

            return new User(emp.getUsername(), emp.getPassword(), List.of(new SimpleGrantedAuthority(emp.getRole())));

//            return User.builder()
//                    .username(emp.getUsername())
//                    .password(emp.getPassword())
//                    .roles(emp.getRole())
//                    .build();
        }
}

