package com.security.controller;

import com.security.entity.Employee;
import com.security.model.CreateUserRequest;
import com.security.service.EmployeeService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final EmployeeService employeeService;

    public EmployeeController(EmployeeService employeeService) {
        this.employeeService = employeeService;
    }

    // USER + ADMIN
    // View all employees (read-only)
    @GetMapping
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public List<Employee> getAllEmployees() {
        return employeeService.findAll();
    }

    // USER + ADMIN
    // View own profile
    @GetMapping("/me")
    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    public Employee getMyProfile(Authentication authentication) {
        return employeeService.findByUsername(authentication.getName());
    }

//    @GetMapping("/me")
//    @PreAuthorize("hasAnyRole('USER', 'ADMIN')")
//    public Employee getMyProfile() {
//        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//        return employeeService.findByUsername(authentication.getName());
//    }

    // ADMIN only
    // Update employee role
    @PutMapping("/{id}/role")
    @PreAuthorize("hasRole('ADMIN')")
    public Employee updateRole(@PathVariable Long id, @RequestParam String role) {
        return employeeService.updateRole(id, role);
    }

    // ADMIN only
    // Delete employee
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public void deleteEmployee(@PathVariable Long id) {
        employeeService.deleteById(id);
    }
}

