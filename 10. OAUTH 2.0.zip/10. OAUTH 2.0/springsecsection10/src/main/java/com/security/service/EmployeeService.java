package com.security.service;

import com.security.entity.Employee;
import com.security.model.CreateUserRequest;
import com.security.repository.EmployeeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EmployeeService {

    private final EmployeeRepository repository;
    // GET /api/employees
    public List<Employee> findAll() {
        return repository.findAll();
    }

    // GET /api/employees/me
    public Employee findByUsername(String username) {
        return repository.findByUsername(username).orElseThrow(() ->
                        new RuntimeException("Employee not found: " + username));
    }

    // PUT /api/employees/{id}/role
    public Employee updateRole(Long id, String role) {
        validateRole(role);
        Employee employee = repository.findById(id).orElseThrow(() ->
                        new RuntimeException("Employee not found with id: " + id));
        employee.setRole(role);
        return repository.save(employee);
    }

    // DELETE /api/employees/{id}
    public void deleteById(Long id) {
        if (!repository.existsById(id)) {
            throw new RuntimeException("Employee not found with id: " + id);
        }
        repository.deleteById(id);
    }

    private void validateRole(String role) {
        if (role == null || role.isBlank()) {
            throw new RuntimeException("Role cannot be empty");
        }

        if (!role.startsWith("ROLE_")) {
            throw new RuntimeException("Role must start with ROLE_");
        }
    }
}



