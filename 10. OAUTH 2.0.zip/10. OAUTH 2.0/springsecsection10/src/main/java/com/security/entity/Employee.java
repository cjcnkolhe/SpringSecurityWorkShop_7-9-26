package com.security.entity;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "employees", schema = "security_authorization")
@Data
public class Employee {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String username;

    @Column(nullable = false)
    private String password;

    // ROLE_USER / ROLE_ADMIN
    @Column(nullable = false)
    private String role;

}
